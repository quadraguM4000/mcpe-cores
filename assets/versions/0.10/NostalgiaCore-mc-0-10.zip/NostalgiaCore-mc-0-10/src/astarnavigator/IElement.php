<?php

interface IElement
{
	public function __toString();
}

