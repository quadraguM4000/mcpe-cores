<?php

interface Tameable
{
    public function isTamed();
    
    public function getOwner();
}

