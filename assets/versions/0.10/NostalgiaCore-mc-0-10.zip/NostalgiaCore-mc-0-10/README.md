![](https://kotyara.nekoweb.org/images/nostalgiacore.png)
## NostalgiaCore 0.10.5 was moved to https://github.com/oldminecraftcommunity/NostalgiaCore-0.9-0.10
