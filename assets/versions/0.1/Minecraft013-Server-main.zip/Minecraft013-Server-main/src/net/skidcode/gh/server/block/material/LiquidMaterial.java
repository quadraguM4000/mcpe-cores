package net.skidcode.gh.server.block.material;

public class LiquidMaterial extends Material{
	public LiquidMaterial() {
		super();
		this.blocksMotion = false;
		this.isLiquid = true;
		this.isSolid = false;
	}
}
