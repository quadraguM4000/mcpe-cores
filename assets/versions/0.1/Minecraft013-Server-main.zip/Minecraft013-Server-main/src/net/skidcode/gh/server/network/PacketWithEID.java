package net.skidcode.gh.server.network;

public interface PacketWithEID {
	public int getEID();
	public void setEID(int eid);
}
