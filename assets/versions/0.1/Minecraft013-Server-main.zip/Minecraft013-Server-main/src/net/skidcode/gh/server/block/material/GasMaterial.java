package net.skidcode.gh.server.block.material;

public class GasMaterial extends Material{
	public GasMaterial() {
		super();
		this.blocksLight = false;
		this.blocksMotion = false;
		this.isSolid = false;
	}
}
