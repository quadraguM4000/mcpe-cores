package net.skidcode.gh.server.utils;

public class BlockFace { //TODO check are 2,3,4,5 correct
	public static final int UP = 0;
	public static final int DOWN = 1;
	public static final int NORTH = 2;
	public static final int SOUTH = 3;
	public static final int EAST = 4;
	public static final int WEST = 5;
}
