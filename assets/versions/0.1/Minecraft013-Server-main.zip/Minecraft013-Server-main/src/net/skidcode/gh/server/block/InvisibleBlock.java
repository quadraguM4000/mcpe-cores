package net.skidcode.gh.server.block;

import net.skidcode.gh.server.block.material.Material;

public class InvisibleBlock extends Block{

	public InvisibleBlock(int id, Material m) {
		super(id, m);
	}
}
