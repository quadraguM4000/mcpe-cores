package net.skidcode.gh.server.block.material;

public class DecorationMaterial extends Material{
	public DecorationMaterial() {
		super();
		this.blocksLight = false;
		this.blocksMotion = false;
		this.isSolid = false;
	}
}
