package net.skidcode.gh.server.world.biome.impl;

import net.skidcode.gh.server.world.biome.Biome;

public class FlatBiome extends Biome{

}
