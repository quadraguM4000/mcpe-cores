package net.skidcode.gh.server.world.biome.impl;

import net.skidcode.gh.server.world.biome.Biome;

public class RainforestBiome extends Biome{
	
}
