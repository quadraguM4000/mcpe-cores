package net.skidcode.gh.server.block;

import net.skidcode.gh.server.block.material.Material;

public class MetalBlock extends Block{

	public MetalBlock(int id) {
		super(id, Material.metal);
	}

}
