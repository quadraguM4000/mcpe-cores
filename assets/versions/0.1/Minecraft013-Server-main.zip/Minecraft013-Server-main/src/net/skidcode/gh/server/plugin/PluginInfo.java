package net.skidcode.gh.server.plugin;

public class PluginInfo {
	public String name, description, author, version, mainClass;
	public int api;
	
}
