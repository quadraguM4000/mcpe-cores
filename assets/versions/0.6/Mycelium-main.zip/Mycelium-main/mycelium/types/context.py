class Context(object):
    def __init__(self, server, raw_data) -> None:
        self.server = server
        self.raw_data = raw_data