# <img src="https://i.imgur.com/nUevR7C.png" width="48" height="48"/> Mycelium 

Mycelium is a low-level simple MCPE (v0.6.1) framework for creating a server.

## Server Example
For a server example visit [examples/server.py](https://github.com/MCPI-Revival/Mycelium/blob/main/examples/server.py)

## Contributing
Pull requests are always welcome. 
If you have any ideas or issues submit them in the [issues tab](https://github.com/MCPI-Revival/Mycelium/issues) on GitHub!
