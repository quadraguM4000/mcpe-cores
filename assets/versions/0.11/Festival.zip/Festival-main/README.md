# PocketMine-MP 1.5dev-1438 fork
Supported versions: 0.11.0-0.11.1 *& prob some builds*

# Features:

* All mobs and eggs

* All blocks *(will be soon)*

* Some vanilla features which were not added

* *and some other bug fixes...*


# PHP8 Binaries:
### PHP8.0 (Not tested, but should work)
* https://github.com/pmmp/PHP-Binaries/releases/tag/pm4-php-8.0-latest PHP8
* https://github.com/DaisukeDaisuke/AndroidPHP/releases/tag/8.0.28 PHP8 for ARMv8
### PHP8.2 (Recommended)
* https://github.com/pmmp/PHP-Binaries/releases/tag/pm4-php-8.2-latest


**Discord: [@eqozqq](https://github.com/eqozqq) thanks for removing it(WIP)**

*wonder will someone read it?*


