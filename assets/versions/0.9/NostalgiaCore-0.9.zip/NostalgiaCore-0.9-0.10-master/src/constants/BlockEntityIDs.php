<?php

//TileEntities
define("TILE_SIGN", "Sign");

define("TILE_CHEST", "Chest");
define("CHEST_SLOTS", 27);

define("TILE_FURNACE", "Furnace");
define("FURNACE_SLOTS", 3);

define("TILE_MOB_SPAWNER", "MobSpawner");

