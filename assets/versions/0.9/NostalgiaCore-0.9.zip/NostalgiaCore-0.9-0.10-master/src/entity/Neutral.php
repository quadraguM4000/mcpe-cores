<?php

abstract class Neutral extends Creature
{
    
}

