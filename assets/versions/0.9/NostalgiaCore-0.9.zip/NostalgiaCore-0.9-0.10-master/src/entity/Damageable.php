<?php

interface Damageable{
	
}