<?php

interface OtherPluginRequirement{
	public function getRequiredPlugins();
}
