<?php
/*abstract class ProtocolInfo{

	public static $CURRENT_PROTOCOL = 14;
	public static function getCurrentProtocolInfo(){
		switch(self::$CURRENT_PROTOCOL) {
			case 14:
				return new ProtocolInfo14();
			case 12:
				return new ProtocolInfo12();
			default:
				return new ProtocolInfo14();
		}
	}

}*/
/***REM_START***/
require_once(FILE_PATH . "src/network/raknet/RakNetDataPacket.php");
/***REM_END***/