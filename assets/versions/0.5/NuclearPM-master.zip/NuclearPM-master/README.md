# NuclearPM
A fork of legacy PocketMine for MCPE 0.5.0

And yes, it is nuclear as HELL!
