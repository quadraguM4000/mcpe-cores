<?php
//Useless Interface
interface Attachable{
	
}